import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SimpleCalculatorService {

  constructor() { }

  public addition(firstNumber: number, lastNumber: number) {
    return firstNumber + lastNumber;
  }

  public subtraction(firstNumber: number, lastNumber: number) {
    return firstNumber - lastNumber;
  }

  public multiplication(firstNumber: number, lastNumber: number) {
    return firstNumber * lastNumber;
  }

  public division(firstNumber: number, lastNumber: number) {
    return firstNumber / lastNumber;
  }

}
