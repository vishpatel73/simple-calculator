import { Component, OnInit } from '@angular/core';
import { Operator } from 'rxjs';
import { OperatorModel, CalculatorModel } from './model';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { SimpleCalculatorService } from './simple-calculator.service';

@Component({
  selector: 'app-simple-calculator',
  templateUrl: './simple-calculator.component.html',
  styleUrls: ['./simple-calculator.component.scss']
})
export class SimpleCalculatorComponent implements OnInit {

  public calculatorFormGroup: FormGroup;
  public result: number;

  constructor(private formBuilder: FormBuilder, private calulatorService: SimpleCalculatorService) {
    this.createCalculatorForm();
  }

  public createCalculatorForm() {
    this.calculatorFormGroup = this.formBuilder.group({
      firstNumber: new FormControl(0, [Validators.required]),
      lastNumber: new FormControl(0, [Validators.required]),
      operatorSign: new FormControl('', [Validators.required]),
    });
  }

  public operators: OperatorModel[] = [
    { text: '+', value: 'Addition' },
    { text: '-', value: 'Subtraction' },
    { text: '*', value: 'Multiplication' },
    { text: '/', value: 'Division' },
  ];

  public calculation(model: CalculatorModel) {
    switch (model.operatorSign) {
      case 'Addition':
        this.result = this.calulatorService.addition(model.firstNumber, model.lastNumber);
        break;
      case 'Subtraction':
        this.result = this.calulatorService.subtraction(model.firstNumber, model.lastNumber);
        break;
      case 'Multiplication':
        this.result = this.calulatorService.multiplication(model.firstNumber, model.lastNumber);
        break;
      case 'Division':
        this.result = this.calulatorService.division(model.firstNumber, model.lastNumber);
        break;
    }
  }

  ngOnInit() {
    this.calculatorFormGroup.valueChanges.subscribe(value => {
      if (this.calculatorFormGroup.invalid) {
        return;
      }
      this.calculation(value);
    });
  }

}
