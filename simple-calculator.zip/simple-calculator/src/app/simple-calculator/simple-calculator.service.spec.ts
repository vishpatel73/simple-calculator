import { TestBed } from '@angular/core/testing';

import { SimpleCalculatorService } from './simple-calculator.service';

describe('SimpleCalculatorService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SimpleCalculatorService = TestBed.get(SimpleCalculatorService);
    expect(service).toBeTruthy();
  });
});
