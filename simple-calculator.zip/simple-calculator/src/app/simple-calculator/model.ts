export class CalculatorModel {
  firstNumber: number;
  lastNumber: number;
  operatorSign: string;
}

export interface OperatorModel {
  text: string;
  value: string;
}
